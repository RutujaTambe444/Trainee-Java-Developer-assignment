import java.util.HashMap;

public class WordCountQue3 {
    public static void main(String[] args) {
        String str = "hello winsoft these Assignmrnts are very very good";

        // Removing punctuation and converting to lowercase for consistent word counting
        str = str.replaceAll("[^a-zA-Z ]", "").toLowerCase();

        // Splitting the string into words
        String[] words = str.split("\\s+");

        // Creating a HashMap to store word counts
        HashMap<String, Integer> wordCountMap = new HashMap<>();

        // Counting occurrences of each word
        for (String word : words) {
            if (wordCountMap.containsKey(word)) {
                // If the word already exists in the HashMap, increment its count
                wordCountMap.put(word, wordCountMap.get(word) + 1);
            } else {
                // If the word is encountered for the first time, add it to the HashMap with count 1
                wordCountMap.put(word, 1);
            }
        }

        // Displaying the word counts
        System.out.println("Word counts:");
        for (String word : wordCountMap.keySet()) {
            System.out.println(word + ": " + wordCountMap.get(word));
        }
        
        // Total number of words
        int totalWords = words.length;
        System.out.println("Total number of words: " + totalWords);
    }
}

